function showBoatGuideline(id){
    var id_text = id + '_text'
    document.getElementById(id_text).innerHTML = '<img src="img/boat_icon/'+ id_text +'.png"/>'
}

function showRiverGuideline(id){
    var id_text = id + '_text'
    document.getElementById(id_text).innerHTML = '<img src="img/river_icon/'+ id_text +'.png"/>'
}

function showPoolGuideline(id){
    var id_text = id + '_text'
    document.getElementById(id_text).innerHTML = '<img src="img/pool_icon/'+ id_text +'.png"/>'
}

function showBeachGuideline(id){
    var id_text = id + '_text'
    document.getElementById(id_text).innerHTML = '<img src="img/beach_icon/'+ id_text +'.png"/>'
}